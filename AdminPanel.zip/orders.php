<?php include_once 'headers/head.php'; ?>
<link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<script src="scripts/orders.js"></script>

<div class="content-wrapper" ng-controller="Orders">
    <section class="content-header">
        <h1>Listing All Orders</h1>
        <small>Click on badge to toggle</small>
    </section>
    <section class="content">
        <div class="box-body">
            <div ng-hide="loader">
                <br>
                <center>
                <img src="dist/img/myloader.gif" width="500px">
                </center>
                <br>
            </div>
            <div class="nav-tabs-custom" ng-hide="tabdata" id="mytabslist">
                <!-- Tabs within a box -->
                <ul class="nav nav-tabs pull-right ui-sortable-handle">
                    <li class=""><a href="#completedOrders" data-toggle="tab" aria-expanded="false">Completed Orders
                            &nbsp;<span class="label label-info">{{totalcompleted}}</span></a></li>
                    <li class=""><a href="#cancelled" data-toggle="tab" aria-expanded="false">Cancelled Orders
                            &nbsp;<span class="label label-danger">{{totalcancelled}}</span></a></li>
                    <li class=""><a href="#pendingOrders" data-toggle="tab" aria-expanded="true">Pending Orders
                            &nbsp;<span class="label label-warning">{{totalpending}}</span></a></li>
                    <li class="active"><a href="#runningOrders" data-toggle="tab" aria-expanded="false">Running Orders
                            &nbsp;<span class="label label-success">{{totalrunning}}</span></a></li>

                    <li class="pull-left header"><i class="fa fa-inbox"></i> Orders Listing</li>
                </ul>
                <div class="tab-content no-padding">
                    <!-- Morris chart - Sales -->
                    <div class="chart tab-pane" id="pendingOrders">
                        <div class="box-body table-responsive" style="margin-top:10px;">
                            <table class="table table-bordered bordered table-striped table-condensed" datatable="ng"
                                dt-options="vm.dtOptions">
                                <thead>
                                    <tr>
                                        <th width="3%">SR</th>
                                        <th>OrderNo / Date</th>
                                        <th>Pickup</th>
                                        <th>Drop</th>
                                        <th>Order Details</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody align="left">
                                    <tr ng-repeat="row in pendingOrders | orderBy:'-dateTime'">
                                        <td>{{$index+1}}</td>
                                        <td>
                                            <div><b>{{row.orderNo}}</b></div>
                                            <div>{{row.dateTime | date:"MM/dd/yyyy"}}</div>
                                            <div>{{row.dateTime | date:"h:mma"}}</div>
                                        </td>
                                        <td>
                                            <b>{{row.pickupPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.pickupPoint.mobileNo}},</div>
                                                    <div>&nbsp;{{row.pickupPoint.completeAddress}}</div>
                                                    <div>&nbsp;<i>{{row.pickupPoint.arriveTime}}
                                                            {{row.pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}</i>
                                                    </div>
                                        </td>
                                        <td>
                                            <b>{{row.deliveryPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.deliveryPoint.mobileNo}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.completeAddress}}</div>
                                            <div>&nbsp;<i>Total Distance : {{row.deliveryPoint.distance}}</i></div>
                                        </td>
                                        <td>
                                            <div><b>Collect Cash</b>: {{row.collectCash}}
                                            </div>
                                            <div><b>Status</b>: {{row.isActive?'Active':'Not Active'}}
                                            </div>
                                            <div><b>Note</b>: <i>{{row.note}}</i>
                                            </div>
                                            <div><b>DeliveryBoy</b>: <i>
                                                    {{row.courierId.length==0?'Not Assigned':row.courierId.firstName}}
                                                    {{row.courierId.length!=0?row.courierId.lastName:""}}
                                                </i>
                                            </div>
                                        </td>
                                        <td>
                                            <div><b>Total</b>: <i>{{row.amount}}</i>
                                            </div>
                                            <div><b>Discount %</b>: <i>{{row.discount}}</i>
                                            </div>
                                            <div><b>Add. Amount</b>: <i>{{row.additionalAmount}}</i>
                                            </div>
                                            <div><b>Net. Amount</b>: <i>{{row.finalAmount}}</i>
                                            </div>
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" title="Cancel Order"
                                                ng-click="CancelOrder(row._id)"><i class="fa fa-times"></i></button>
                                            <button class="btn btn-info btn-sm" title="Assign To Delivery Boy"
                                                ng-click="AssignPoup(row._id,row.orderNo)"><i
                                                    class="fa fa-list"></i></button>
                                            <button class="btn btn-danger btn-sm" title="Cancel Order"><i
                                                    class="fa fa-close"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="chart tab-pane" id="completedOrders">
                        <div class="box-body table-responsive" style="margin-top:10px;">
                            <table class="table table-bordered bordered table-striped table-condensed" datatable="ng"
                                dt-options="vm.dtOptions">
                                <thead>
                                    <tr>
                                        <th width="3%">SR</th>
                                        <th>OrderNo / Date</th>
                                        <th>Pickup</th>
                                        <th>Drop</th>
                                        <th>Order Details</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody align="left">
                                    <tr ng-repeat="row in completeOrders | orderBy:'-dateTime'">
                                        <td>{{$index+1}}</td>
                                        <td>
                                        <div><b>{{row.orderNo}}</b></div>
                                            <div>{{row.dateTime | date:"MM/dd/yyyy h:mma"}}</div>
                                        </td>
                                        <td>
                                            <b>{{row.pickupPoint.name}}</b>,<br/>
                                            <div>&nbsp;{{row.pickupPoint.mobileNo}},</div>
                                                    <div>&nbsp;{{row.pickupPoint.completeAddress}},</div>
                                                    <div>&nbsp;{{row.pickupPoint.address}}</div>
                                                    <div>&nbsp;<i>{{row.pickupPoint.arriveTime}}
                                                            {{row.pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}</i>
                                                    </div>
                                        </td>
                                        <td>
                                            <b>{{row.deliveryPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.deliveryPoint.mobileNo}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.completeAddress}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.address}}</div>
                                            <div>&nbsp;<i>Total Distance : {{row.deliveryPoint.distance}}</i></div>
                                        </td>
                                        <td>
                                            <div><b>Collect Cash</b>: {{row.collectCash}}
                                            </div>
                                            <div><b>Status</b>: {{row.isActive?'Active':'Not Active'}}
                                            </div>
                                            <div><b>Note</b>: <i>{{row.note}}</i>
                                            </div>
                                            <div><b>DeliveryBoy</b>: <i>
                                                    {{row.courierId.length==0?'Not Assigned':row.courierId[0].firstName}}
                                                    {{row.courierId.length!=0?row.courierId[0].lastName:""}}
                                                </i>
                                            </div>
                                        </td>
                                        <td>
                                            <div><b>Total</b>: <i>{{row.amount}}</i>
                                            </div>
                                            <div><b>Discount %</b>: <i>{{row.discount}}</i>
                                            </div>
                                            <div><b>Add. Amount</b>: <i>{{row.additionalAmount}}</i>
                                            </div>
                                            <div><b>Net. Amount</b>: <i>{{row.finalAmount}}</i>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="chart tab-pane active" id="runningOrders">
                        <div class="box-body table-responsive" style="margin-top:10px;">
                            <table class="table table-bordered bordered table-striped table-condensed" datatable="ng"
                                dt-options="vm.dtOptions">
                                <thead>
                                    <tr>
                                        <th width="3%">SR</th>
                                        <th>OrderNo / Date</th>
                                        <th>Pickup</th>
                                        <th>Drop</th>
                                        <th>Order Details</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody align="left">
                                    <tr ng-repeat="row in runningOrders | orderBy:'-dateTime'">
                                        <td>{{$index+1}}</td>
                                        <td>
                                        <div><b>{{row.orderNo}}</b></div>
                                            <div>{{row.dateTime | date:"MM/dd/yyyy h:mma"}}</div>
                                        </td>
                                        <td>
                                            <b>{{row.pickupPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.pickupPoint.mobileNo}},<div>
                                                    <div>&nbsp;{{row.pickupPoint.completeAddress}},</div>
                                                    <div>&nbsp;{{row.pickupPoint.address}}</div>
                                                    <div>&nbsp;<i>{{row.pickupPoint.arriveTime}}
                                                            {{row.pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}</i>
                                                    </div>
                                        </td>
                                        <td>
                                            <b>{{row.deliveryPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.deliveryPoint.mobileNo}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.completeAddress}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.address}}</div>
                                            <div>&nbsp;<i>Total Distance : {{row.deliveryPoint.distance}}</i></div>
                                        </td>
                                        <td>
                                            <div><b>Collect Cash</b>: {{row.collectCash}}
                                            </div>
                                            <div><b>Status</b>: {{row.isActive?'Active':'Not Active'}}
                                            </div>
                                            <div><b>Note</b>: <i>{{row.note}}</i>
                                            </div>
                                            <div><b>DeliveryBoy</b>: <i>
                                                    {{row.courierId.length==0?'Not Assigned':row.courierId[0].firstName}}
                                                    {{row.courierId.length!=0?row.courierId[0].lastName:""}}
                                                </i>
                                            </div>
                                        </td>
                                        <td>
                                            <div><b>Total</b>: <i>{{row.amount}}</i>
                                            </div>
                                            <div><b>Discount %</b>: <i>{{row.discount}}</i>
                                            </div>
                                            <div><b>Add. Amount</b>: <i>{{row.additionalAmount}}</i>
                                            </div>
                                            <div><b>Net. Amount</b>: <i>{{row.finalAmount}}</i>
                                            </div>
                                        </td>
                                        <td>
                                            <button class="btn btn-danger btn-sm" title="Cancel Order"
                                                ng-click="CancelOrder(row._id)" ng-show="row.courierId.length==0?true:false"><i class="fa fa-times"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="chart tab-pane" id="cancelled">
                        <div class="box-body table-responsive" style="margin-top:10px;">
                            <table class="table table-bordered bordered table-striped table-condensed" datatable="ng"
                                dt-options="vm.dtOptions">
                                <thead>
                                    <tr>
                                        <th width="3%">SR</th>
                                        <th>OrderNo / Date</th>
                                        <th>Pickup</th>
                                        <th>Drop</th>
                                        <th>Order Details</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody align="left">
                                    <tr ng-repeat="row in cancelledOrders | orderBy:'-dateTime'">
                                        <td>{{$index+1}}</td>
                                        <td>
                                        <div><b>{{row.orderNo}}</b></div>
                                            <div>{{row.dateTime | date:"MM/dd/yyyy h:mma"}}</div>
                                        </td>
                                        <td>
                                            <b>{{row.pickupPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.pickupPoint.mobileNo}},<div>
                                                    <div>&nbsp;{{row.pickupPoint.completeAddress}},</div>
                                                    <div>&nbsp;{{row.pickupPoint.address}}</div>
                                                    <div>&nbsp;<i>{{row.pickupPoint.arriveTime}}
                                                            {{row.pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}</i>
                                                    </div>
                                        </td>
                                        <td>
                                            <b>{{row.deliveryPoint.name}}</b>,<br>
                                            <div>&nbsp;{{row.deliveryPoint.mobileNo}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.completeAddress}},</div>
                                            <div>&nbsp;{{row.deliveryPoint.address}}</div>
                                            <div>&nbsp;<i>Total Distance : {{row.deliveryPoint.distance}}</i></div>
                                        </td>
                                        <td>
                                            <div><b>Collect Cash</b>: {{row.collectCash}}
                                            </div>
                                            <div><b>Status</b>: {{row.isActive?'Active':'Not Active'}}
                                            </div>
                                            <div><b>Note</b>: <i>{{row.note}}</i>
                                            </div>
                                            <div><b>DeliveryBoy</b>: <i>
                                                    {{row.courierId.length==0?'Not Assigned':row.courierId[0].firstName}}
                                                    {{row.courierId.length!=0?row.courierId[0].lastName:""}}
                                                </i>
                                            </div>
                                        </td>
                                        <td>
                                            <div><b>Total</b>: <i>{{row.amount}}</i>
                                            </div>
                                            <div><b>Discount %</b>: <i>{{row.discount}}</i>
                                            </div>
                                            <div><b>Add. Amount</b>: <i>{{row.additionalAmount}}</i>
                                            </div>
                                            <div><b>Net. Amount</b>: <i>{{row.finalAmount}}</i>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="modal fade" id="AssignOrders" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><b>{{orderNo}}</b></h4>
                </div>
                <div class="modal-body">
                    <form ng-submit="AssignOrderTODB()">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>SELECT DELIVERY BOY </label> : &nbsp;<button class="btn btn-default btn-xs"
                                        ng-click="getAvailableBoys()"><i class="fa fa-refresh"></i></button> &nbsp;
                                    <span style="color:red">{{errmsg}}</span>
                                    <select class="form-control" ng-model="selectedDeliveryBoy" required>
                                        <option value="">~ NOTHING SELECTED ~</option>
                                        <option ng-repeat="sel in availableData"
                                            ng-selected="selectedDeliveryBoy == sel.Id" value="{{sel.Id}}">{{sel.name}}
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" value="Assign"></div>
                            </div>
                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

<?php include_once 'headers/foot.php'; ?>