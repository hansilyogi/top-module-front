<?php include_once 'headers/head.php'; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCW-CryHApwFarrX9piqmNKo-E_ZxAlYJU&libraries=geometry">
</script>
<link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<script src="scripts/extrakms.js"></script>

<div class="content-wrapper" ng-controller="ExtraKms">
    <section class="content-header">
        <h1>Extra kilometers travelled by delivery boys</h1>
        <small>Here you can find, how much kilometer travelled by delivery boys using date filter.</small>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
            <div ng-show="loader">
                                    <br>
                                    <center>
                                    <img src="dist/img/myloader.gif" width="500px">
                                    </center>
                                    <br>
                                </div>
                <div class="box" ng-show="tabdata">
                    <div class="box-body">
                        <div class="table-responsive" style="margin-top:20px;" >
                            <table class="mydab table table-bordered bordered table-striped table-condensed" datatable="ng" dt-options="vm.dtOptions">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Total Orders</th>
                                        <th>P-D Kilometers</th>
                                        <th>Extra Kilometers</th>
                                        <th>Total Earnings</th>
                                        <th>Amount To Pay</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr ng-repeat="data in FullData">
                                        <td>{{data.name}}</td>
                                        <td>{{data.orderdata.length}}</td>
                                        <td>{{data.orderkm}} Km</td>
                                        <td>{{data.extrakm}} Km</td>
                                        <td>₹{{data.totalearning}}</td>
                                        <td>₹{{data.amttopay}}</td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" title="Orders List">
                                                <i class="fas fa-list"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!-- /.col -->
        </div>


        <div class="modal fade" id="orderModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><b>{{orderModelId}}</b></h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <td>
                                            <b>Pickup Point</b><br>
                                            <div>{{OrderDetails[0].pickupPoint.name}},</div>
                                            <div>{{OrderDetails[0].pickupPoint.mobileNo}},</div>
                                            <div>{{OrderDetails[0].pickupPoint.completeAddress}},</div>
                                            <div>{{OrderDetails[0].pickupPoint.address}}</div>
                                        </td>
                                        <td>
                                            <b>Delivery Point</b><br>
                                            <div>{{OrderDetails[0].deliveryPoint.name}},</div>
                                            <div>{{OrderDetails[0].deliveryPoint.mobileNo}},</div>
                                            <div>{{OrderDetails[0].deliveryPoint.completeAddress}},</div>
                                            <div>{{OrderDetails[0].deliveryPoint.address}}</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <b>Arrive Time</b><br>
                                            {{OrderDetails[0].pickupPoint.arriveTime}}
                                            {{OrderDetails[0].pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}
                                        </td>
                                        <td>
                                            <b>Parcel Contents</b><br>
                                            {{OrderDetails[0].pickupPoint.contents}}</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div><b>Total</b>: <i>{{OrderDetails[0].amount}}</i></div>
                                            <div><b>Discount %</b>: <i>{{OrderDetails[0].discount}}</i></div>
                                            <div><b>Add. Amount</b>: <i>{{OrderDetails[0].additionalAmount}}</i></div>
                                            <div><b>Net. Amount</b>: <i>{{OrderDetails[0].finalAmount}}</i></div>
                                        </td>
                                        <td>
                                            <div><b>Collect Cash</b>: {{OrderDetails[0].collectCash}}</div>
                                            <div><b>Status</b>: {{OrderDetails[0].isActive?'Active':'Not Active'}}</div>
                                            <div><b>Note</b>: {{OrderDetails[0].note}}</div>
                                            <div><b>Date</b>: {{OrderDetails[0].dateTime | date:"MM/dd/yyyy"}}
                                                {{OrderDetails[0].dateTime | date:"h:mma"}}</div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </section>
</div>

<?php include_once 'headers/foot.php'; ?>