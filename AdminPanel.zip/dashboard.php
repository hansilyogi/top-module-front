<?php include_once 'headers/head.php'; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCW-CryHApwFarrX9piqmNKo-E_ZxAlYJU"></script>
<link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
<script src="scripts/dashboard.js"></script>

<div class="content-wrapper" ng-controller="Dashboard">
    <section class="content-header">
        <h1>
            Dashboard
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
    <section class="content">

        <div class="row">
            <div class="col-md-12">
                <div class="nav-tabs-custom" ng-hide="tabdata">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs pull-right ui-sortable-handle">
                        <li class="active"><a href="#revenue-chart" data-toggle="tab" aria-expanded="true">Pending
                                Orders &nbsp;<span class="label label-danger">{{totalpendingOrders}}</span></a></li>
                        <li class="pull-left header"><i class="fa fa-history"></i> Pending Orders</li>
                    </ul>
                    <div class="tab-content no-padding">
                        <!-- Morris chart - Sales -->
                        <div class="chart tab-pane active" id="revenue-chart">
                            <div class="box-body table-responsive" style="margin-top:10px;">
                                <div ng-show="loader">
                                    <br>
                                    <center>
                                    <img src="dist/img/myloader.gif" width="500px">
                                    </center>
                                    <br>
                                </div>
                                <table class="table table-bordered bordered table-striped table-condensed"
                                    datatable="ng" dt-options="vm.dtOptions">
                                    <thead>
                                        <tr>
                                            <th width="3%">SR</th>
                                            <th>OrderNo / Date</th>
                                            <th>Pickup</th>
                                            <th>Drop</th>
                                            <th>Order Details</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody align="left">
                                        <tr ng-repeat="row in PendingOrders | orderBy:'-dateTime'">
                                            <td>{{$index+1}}</td>
                                            <td>
                                                <div><b>{{row.orderNo}}</b></div>
                                                <div>{{row.dateTime | date:"MM/dd/yyyy"}}</div>
                                                <div>{{row.dateTime | date:"h:mma"}}</div>
                                            </td>
                                            <td>
                                                <b>{{row.pickupPoint.name}}</b>,<br>
                                                <div>&nbsp;{{row.pickupPoint.mobileNo}},
                                                    <div>
                                                        <div>&nbsp;{{row.pickupPoint.completeAddress}}</div>
                                                        <div>&nbsp;<i>{{row.pickupPoint.arriveTime}}
                                                                {{row.pickupPoint.arriveType=='rightnow'?'Current':'Scheduled'}}</i>
                                                        </div>
                                            </td>
                                            <td>
                                                <b>{{row.deliveryPoint.name}}</b>,<br>
                                                <div>&nbsp;{{row.deliveryPoint.mobileNo}},</div>
                                                <div>&nbsp;{{row.deliveryPoint.completeAddress}}</div>
                                                <div>&nbsp;<i>Total Distance : {{row.deliveryPoint.distance}}</i></div>
                                            </td>
                                            <td>
                                                <div><b>Collect Cash</b>: {{row.collectCash}}
                                                </div>
                                                <div><b>Status</b>: {{row.isActive?'Active':'Not Active'}}
                                                </div>
                                                <div><b>Note</b>: <i>{{row.note}}</i>
                                                </div>
                                                <div><b>DeliveryBoy</b>: <i>
                                                        {{row.courierId.length==0?'Not Assigned':row.courierId.firstName}}
                                                        {{row.courierId.length!=0?row.courierId.lastName:""}}
                                                    </i>
                                                </div>
                                            </td>
                                            <td>
                                                <div><b>Total</b>: <i>{{row.amount}}</i>
                                                </div>
                                                <div><b>Discount %</b>: <i>{{row.discount}}</i>
                                                </div>
                                                <div><b>Add. Amount</b>: <i>{{row.additionalAmount}}</i>
                                                </div>
                                                <div><b>Net. Amount</b>: <i>{{row.finalAmount}}</i>
                                                </div>
                                            </td>
                                            <td>
                                                <button class="btn btn-info btn-sm" title="Assign To Delivery Boy"
                                                    ng-click="AssignPoup(row._id,row.orderNo)"><i
                                                        class="fa fa-list"></i></button>
                                                <button class="btn btn-danger btn-sm" title="Cancel Order" ng-click="CancelOrder(row._id)"><i
                                                        class="fa fa-close"></i></button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="nav-tabs-custom" ng-hide="tabdata">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs pull-right ui-sortable-handle" style="padding:10px">
                        <li class="pull-left header"><i class="fas fa-map-marked-alt"></i> Realtime location of delivery
                            boys</li>
                        <li class="pull-right header"><b>Available :</b> {{locationcounter}}</li>
                    </ul>
                    <div class="tab-content no-padding">
                        <div class="chart tab-pane active" id="mapper">
                            <div id="map" style="min-height:500px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <div class="modal fade" id="AssignOrders" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><b>{{orderNo}}</b></h4>
                </div>
                <div class="modal-body">
                    <form ng-submit="AssignOrderTODB()">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>SELECT DELIVERY BOY </label> : &nbsp;<button class="btn btn-default btn-xs"
                                        ng-click="getAvailableBoys()"><i class="fa fa-refresh"></i></button> &nbsp;
                                    <span style="color:red">{{errmsg}}</span>
                                    <select class="form-control" ng-model="selectedDeliveryBoy" required>
                                        <option value="">~ NOTHING SELECTED ~</option>
                                        <option ng-repeat="sel in availableData"
                                            ng-selected="selectedDeliveryBoy == sel.Id" value="{{sel.Id}}">{{sel.name}}
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" value="Assign"></div>
                            </div>
                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once 'headers/foot.php'; ?>